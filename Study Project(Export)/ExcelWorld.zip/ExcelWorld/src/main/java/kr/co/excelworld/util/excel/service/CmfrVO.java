package kr.co.excelworld.util.excel.service;

public class CmfrVO {

	/** 나눔숲 일련번호 */
	private int cmfrConno;
	
	/** 나눔숲 조성연도 */
	private int cmfrMkYr;
	
	/** 나눔숲 사업명 */
	private String cmfrBsnssNm;
	
	/** 나눔숲 기관명 */
	private String cmfrInsttNm;
	
	/** 나눔숲 세부사업명 */
	private String cmfrDetlBsnssNm;
	
	/** 나눔숲 주소 */
	private String cmfrAddr;
	
	/** 나눔숲 지원금액 */
	private int cmfrSpprtAmt;
	
	/** 나눔숲 면적 */
	private float cmfrArea;

	
	
	/** getter setter */
	
	public int getCmfrConno() {
		return cmfrConno;
	}

	public void setCmfrConno(int cmfrConno) {
		this.cmfrConno = cmfrConno;
	}

	public int getCmfrMkYr() {
		return cmfrMkYr;
	}

	public void setCmfrMkYr(int cmfrMkYr) {
		this.cmfrMkYr = cmfrMkYr;
	}

	public String getCmfrBsnssNm() {
		return cmfrBsnssNm;
	}

	public void setCmfrBsnssNm(String cmfrBsnssNm) {
		this.cmfrBsnssNm = cmfrBsnssNm;
	}

	public String getCmfrInsttNm() {
		return cmfrInsttNm;
	}

	public void setCmfrInsttNm(String cmfrInsttNm) {
		this.cmfrInsttNm = cmfrInsttNm;
	}

	public String getCmfrDetlBsnssNm() {
		return cmfrDetlBsnssNm;
	}

	public void setCmfrDetlBsnssNm(String cmfrDetlBsnssNm) {
		this.cmfrDetlBsnssNm = cmfrDetlBsnssNm;
	}

	public String getCmfrAddr() {
		return cmfrAddr;
	}

	public void setCmfrAddr(String cmfrAddr) {
		this.cmfrAddr = cmfrAddr;
	}

	public int getCmfrSpprtAmt() {
		return cmfrSpprtAmt;
	}

	public void setCmfrSpprtAmt(int cmfrSpprtAmt) {
		this.cmfrSpprtAmt = cmfrSpprtAmt;
	}

	public float getCmfrArea() {
		return cmfrArea;
	}

	public void setCmfrArea(float cmfrArea) {
		this.cmfrArea = cmfrArea;
	}
}