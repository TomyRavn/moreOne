package kr.co.excelworld;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FilenameUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import kr.co.excelworld.util.excel.ExcelVO;
import kr.co.excelworld.util.excel.ExcelWrite;
import kr.co.excelworld.util.excel.service.CmfrVO;
import kr.co.excelworld.util.excel.service.FileService;

@Controller
public class HomeController {

	@Autowired
	private FileService fileService;

	@RequestMapping("/")
	public String index(ModelMap model) {

		//test
		//		List<CmrdVO> cmrdList = fileService.selectColumnList();
		//		model.addAttribute("cmrdList", cmrdList);

//		List<CmrdVO> cmrdList = fileService.selectColumnList();
//		List<String> searchColumnList = new ArrayList<String>();
//		
//		for(int i = 0 ; i < cmrdList.size(); i++) {
//			searchColumnList.add(cmrdList.get(i).getCmrdAddr());
//		}
//		
//		model.addAttribute("searchColumnList", searchColumnList);
		
		return "index";

	}

	@RequestMapping("/download.do")
	public String saveFile(HttpServletRequest request, HttpServletResponse response, ModelMap model,
			MultipartFile multiFile, MultipartHttpServletRequest multiRequest) throws Exception {

		/***********/
		/* 파일 체크 */
		/***********/
		MultipartFile userFile = multiRequest.getFile("userFile");

		if (userFile == null || userFile.isEmpty()) {
			throw new RuntimeException("파일을 선택하지 않았습니다.");
		}

		String ext = userFile.getOriginalFilename().substring(userFile.getOriginalFilename().lastIndexOf(".") + 1);

		if (!(ext.equals("xlsx") || ext.equals("xls") || ext.equals("csv") || ext.equals("xlsm"))) {
			throw new RuntimeException("엑셀 파일을 선택해주세요.");
		}

		/*****************/
		/* 데이터 검수(비교) */
		/*****************/
		//1. 파일 데이터

		/** 컬럼 갯수 변경 필요 부분 */
		int columnCount = 8;

		List<List<String>> excelContent = new ArrayList<List<String>>();
		excelContent = fileService.readExcelSheet(userFile, columnCount);

		//2. DB 데이터
		List<CmfrVO> columnList = fileService.selectColumnList();
		int maxConno = fileService.maxConno();

		//3. 필요 리스트 생성
		List<String> searchColumnList = new ArrayList<String>();
		List<List<String>> newContent = new ArrayList<List<String>>();

		//4. 검색할 컬럼값만 리스트로 작성
		for(CmfrVO cmfrVO : columnList) {
			searchColumnList.add(cmfrVO.getCmfrDetlBsnssNm());
		}
		
//		System.out.println(excelContent.size()); 		//65  1230
//		System.out.println(columnList.size()); 			//64  1029
//		System.out.println(searchColumnList1.size());	//64  1029
//		System.out.println(searchColumnList2.size());	//64  1029
		
		//5. 비교
		boolean isSame1;
		boolean isSame2;
		String selectAddr;
		String temp;
		CmfrVO cmfrVO = new CmfrVO();
		
		for(int i = 1 ; i < excelContent.size(); i++) {
			
			isSame1 = false;
			isSame2 = false;
			selectAddr = "";
			temp = "";
			
			for(int j = 0; j < excelContent.get(i).size(); j++) {
				
				//CMFR_DETL_BSNSS_NM
				if(j % columnCount == 4) {
					
					//DB에서 추출한 사업명 list에 해당 엑셀 열이 있는지 확인
					if(searchColumnList.contains(excelContent.get(i).get(j))) {
						
						//사업명 해당 셀이 빈칸이 아닐시
						if(excelContent.get(i).get(j) != null && !(excelContent.get(i).get(j).equals(""))) {
							
							cmfrVO.setCmfrDetlBsnssNm(excelContent.get(i).get(j));
							//주소를 저장
							temp = fileService.selectColumn(cmfrVO).getCmfrAddr();
							
							System.out.println("temp : " + temp);
							
							//주소가 DB에서 null값인 경우 공백칸으로, 아닐 경우 DB 그대로
							if(temp == null) selectAddr = "";
							else selectAddr = temp;							
						}
						
						System.out.println("bsnss : " + excelContent.get(i).get(j));
						System.out.println("selectAddr : " + selectAddr);
						
						isSame1 = true;
					}
				}
				
				if(isSame1) {
					if(j % columnCount == 5) {
						if(selectAddr.equals(excelContent.get(i).get(j))) {
							
							System.out.println("excel : " + excelContent.get(i).get(j));
							isSame2 = true;
						}else {
							isSame1 = false;
						}
					}
				}
				
			}
			
			if(!isSame2) {
				for(int k = 0; k < excelContent.get(i).size(); k++) {
					if(k == 0) {
						newContent.add(new ArrayList<String>());
						newContent.get(i-1).add(Integer.toString(maxConno + 1));
						maxConno += 1;
					}else {
						newContent.get(i-1).add(excelContent.get(i).get(k));
					}
					
//					System.out.println("excel" + i + ", " + k + ":" + excelContent.get(i).get(k));
//					System.out.println("new" + i + ", " + k + ":" + newContent.get(i-1).get(k));
				}
//			}
//			else { //중복데이터 출력 여부 결정
//				for(int l = 0; l < excelContent.get(i).size(); l++) {
//					if(l == 0) {
//						newContent.add(new ArrayList<String>());
//					}else {
//						newContent.get(i-1).add(excelContent.get(i).get(l));
//					}
//				}
			}
		}
		
		
		//		
		//		for(int i = 0; i < cmrdList.size(); i++) {
		//			cmrdList.get(i).getCmrdConno();
		//			cmrdList.get(i).getCmrdMkYr();
		//			cmrdList.get(i).getCmrdBsnssNm();
		//			cmrdList.get(i).getCmrdInsttNm();
		//			cmrdList.get(i).getCmrdDetlBsnssNm();
		//			cmrdList.get(i).getCmrdAddr();
		//			cmrdList.get(i).getCmrdSpprtAmt();
		//			cmrdList.get(i).getCmrdArea();
		//		}

		//		System.out.println(excelContent.size());
		//		System.out.println(cmrdList.size());

		/***********/
		/* 파일 작성 */
		/***********/
		ExcelWrite write = new ExcelWrite();
		ExcelVO excelVO = new ExcelVO();
		excelVO.setWb(new HSSFWorkbook());
		excelVO.setSheet(excelVO.getWb().createSheet());
		excelVO.setStyle(excelVO.getWb().createCellStyle());

		for (int i = 0; i < newContent.size(); i++) {

			write.rowInit(excelVO, 0);

			for (int j = 0; j < newContent.get(i).size(); j++) {

				//공백일 때 빈칸으로 처리
				if (newContent.get(i).get(j).equals("")) {
					write.addNewCell(excelVO, Cell.CELL_TYPE_BLANK);
				} else {
					//정수에 소수점 나오는 것 방지
					if ((newContent.get(i).get(j).substring(newContent.get(i).get(j).lastIndexOf(".") + 1)
							.equals("0")))
						write.addNewCell(excelVO, FilenameUtils.getBaseName(newContent.get(i).get(j)));
					else
						write.addNewCell(excelVO, 0, 0, newContent.get(i).get(j));
				}
			}

		}

		/***********/
		/* 파일 저장 */
		/***********/
		String fileName = userFile.getOriginalFilename();

		String header = request.getHeader("User-Agent");
		if (header.contains("MSIE") || header.contains("Trident")) {
			fileName = URLEncoder.encode(fileName, "UTF-8").replaceAll("\\+", "%20");
			response.setHeader("Content-Disposition", "attachment;filename=" + fileName + ";");
		} else {
			fileName = new String(fileName.getBytes("UTF-8"), "ISO-8859-1");
			response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
		}

		ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
		excelVO.getWb().write(outByteStream);

		byte[] outArray = outByteStream.toByteArray();
		response.setContentType("application/ms-excel");
		response.setHeader("Expires:", "0");
		response.setHeader("Content-Length", Long.toString(outArray.length));
		response.setHeader("Content-Disposition",
				"attachment; filename=" + FilenameUtils.getBaseName(fileName) + ".xls");
		OutputStream outStream = response.getOutputStream();
		outStream.write(outArray);
		outStream.flush();
		outStream.close();

		return "redirect:/";

	}
}
