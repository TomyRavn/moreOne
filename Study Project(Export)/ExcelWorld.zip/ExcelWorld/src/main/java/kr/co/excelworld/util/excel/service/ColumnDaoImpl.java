package kr.co.excelworld.util.excel.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class ColumnDaoImpl implements ColumnDao {

	@Autowired
	SqlSession sql;
	
	@Override
	public List<CmfrVO> selectColumnList() {
		return sql.selectList("column.selectColumnList");
	}

	@Override
	public int maxConno() {
		return sql.selectOne("column.maxConno");
	}

	@Override
	public CmfrVO selectColumn(CmfrVO cmfrVO) {
		return sql.selectOne("column.selectColumn", cmfrVO);
	}

}
