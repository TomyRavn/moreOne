package kr.co.excelworld.util.excel.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import kr.co.excelworld.util.excel.ExcelRead;
import kr.co.excelworld.util.excel.ReadOption;

@Service("FileService")
public class FileServiceImpl implements FileService {
	
	@Autowired
	ColumnDao columnDao;
	
	
	@Override
	public List<List<String>> readExcelSheet(MultipartFile multiFile, int columnCount) throws Exception {
		ReadOption readOption = new ReadOption();

		readOption.setFile(multiFile);
		readOption.setStartRow(1);

		List<List<String>> excelContent = new ArrayList<List<String>>();
		
		/* '컬럼 갯수 변경'이 필요한 곳*/
		excelContent = ExcelRead.read(readOption, columnCount);

		return excelContent;
	}

	@Override
	public List<CmfrVO> selectColumnList() {
		return columnDao.selectColumnList();
	}

	@Override
	public int maxConno() {
		return columnDao.maxConno();
	}

	@Override
	public CmfrVO selectColumn(CmfrVO cmfrVO) {
		return columnDao.selectColumn(cmfrVO);
	}
}