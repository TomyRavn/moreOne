package kr.co.excelworld.util.excel.service;

public class CmrdVO {

	/** 나눔길 일련번호 */
	private int cmrdConno;
	
	/** 나눔길 조성연도 */
	private int cmrdMkYr;
	
	/** 나눔길 사업명 */
	private String cmrdBsnssNm;
	
	/** 나눔길 기관명 */
	private String cmrdInsttNm;
	
	/** 나눔길 세부사업명 */
	private String cmrdDetlBsnssNm;
	
	/** 나눔길 주소 */
	private String cmrdAddr;
	
	/** 나눔길 지원금액 */
	private int cmrdSpprtAmt;
	
	/** 나눔길 면적 */
	private float cmrdArea;

	
	
	/** getter setter */
	
	public int getCmrdConno() {
		return cmrdConno;
	}

	public void setCmrdConno(int cmrdConno) {
		this.cmrdConno = cmrdConno;
	}

	public int getCmrdMkYr() {
		return cmrdMkYr;
	}

	public void setCmrdMkYr(int cmrdMkYr) {
		this.cmrdMkYr = cmrdMkYr;
	}

	public String getCmrdBsnssNm() {
		return cmrdBsnssNm;
	}

	public void setCmrdBsnssNm(String cmrdBsnssNm) {
		this.cmrdBsnssNm = cmrdBsnssNm;
	}

	public String getCmrdInsttNm() {
		return cmrdInsttNm;
	}

	public void setCmrdInsttNm(String cmrdInsttNm) {
		this.cmrdInsttNm = cmrdInsttNm;
	}

	public String getCmrdDetlBsnssNm() {
		return cmrdDetlBsnssNm;
	}

	public void setCmrdDetlBsnssNm(String cmrdDetlBsnssNm) {
		this.cmrdDetlBsnssNm = cmrdDetlBsnssNm;
	}

	public String getCmrdAddr() {
		return cmrdAddr;
	}

	public void setCmrdAddr(String cmrdAddr) {
		this.cmrdAddr = cmrdAddr;
	}

	public int getCmrdSpprtAmt() {
		return cmrdSpprtAmt;
	}

	public void setCmrdSpprtAmt(int cmrdSpprtAmt) {
		this.cmrdSpprtAmt = cmrdSpprtAmt;
	}

	public float getCmrdArea() {
		return cmrdArea;
	}

	public void setCmrdArea(float cmrdArea) {
		this.cmrdArea = cmrdArea;
	}
}