package kr.co.excelworld.util.excel.service;

import java.util.List;

public interface ColumnDao {
	
	List<CmfrVO> selectColumnList();

	int maxConno();

	CmfrVO selectColumn(CmfrVO cmfrVO);
	
}