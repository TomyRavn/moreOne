package kr.co.excelworld.util.excel.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

public interface FileService {
	
	public List<List<String>> readExcelSheet(MultipartFile multiFile, int columnCount) throws Exception;

	public List<CmfrVO> selectColumnList();

	public int maxConno();

	public CmfrVO selectColumn(CmfrVO cmfrVO);
	
}